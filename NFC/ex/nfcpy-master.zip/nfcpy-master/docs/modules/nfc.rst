nfc
===

nfc.ContactlessFrontend
-----------------------

.. class:: nfc.ContactlessFrontend

   Shorthand for :class:`nfc.clf.ContactlessFrontend`.
