nfc.llcp
========

.. automodule:: nfc.llcp

nfc.llcp.Socket
---------------

.. autoclass:: nfc.llcp.Socket
   :members:

nfc.llcp.llc.LogicalLinkController
----------------------------------

.. autoclass:: nfc.llcp.llc.LogicalLinkController
   :members:

